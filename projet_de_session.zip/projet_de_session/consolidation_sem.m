% Lire "Lisez-moi.txt" pour plus de détails sur l'utilisation du script et
% sur la procédure de chacune des phases

% La première phase (1)  est la phase de mémorisation. Elle consiste à présenter
% une image d'objet pairée avec un non-mot à chaque 5 secondes (nombre de
% paires = 18; 90s). À la fin de la présentation, l'utilisateur a la
% possibilité de continuer directement à la phase 2 ou de fermer la
% fenêtre.

% La deuxième phase (2) est la phase de reconnaissance de l'expérimentation pour
% mesurer la consolidation sémantique. Un non-mot présenté lors de la phase
% 1 est présenté au centre-bas de l'écran et deux catégories sémantique (e.g. animal)
% apparaissent en haut à gauche et en haut à droite. Le participant doit appuyer sur 
% "z" pour sélectionner la catégorie de gauche et "m" pour sélectionner la catégorie de droite.

%% Nettoyer le workspace et l'écran des précédentes opérations
clc;
close all;
clear all;
%% IMPORTANT
% Si c'est la première fois que le script est exécuté, laissez la valeur 1
% à la variable phase
% Si vous voulez directement procéder à la phase expérimentale, changez la
% valeur de phase pour 2.
phase = 1;
%% Initialisation des variables

% Renvoie un message d'erreur si la version de PsychToolBox n'est pas basée
% sur OpenGL ou si Screen() ne fonctionne pas bien
AssertOpenGL;

% Amorce le générateur de nombres aléatoires afin que tous les nombres générés soient vraiment "aléatoires"
rng('shuffle');

% Initialiser la fonction de structure pour éventuellement entrer les
% informations du participant et ses TR
info_par = struct;

% Demander numéro de participant dans la Command Window
num_par = input('Numéro de participant: ');
info_par.NumParticipant = num_par;
    
% Matrice des non-mots sous leur catégorie sémantique correspondante
m_catEtNonMot = ["Bureau" "Animal" "Sport" "Plante" "Breuvage" "Fruit" "Insecte" "Légume" "Meuble";...
"gecolêt" "lêmobur" "kasifoc" "sarybêt" "labèlel" "lenêcheg" "tâfethor" "gugareg" "ramomet";...
"fanisîr" "cosonem" "cémacèm" "cynofép" "botamom" "ceduphèc" "yarevat" "gasafod" "poçamec"];

% Matrice contenant des catégorie sémantiques qui ne seront pas présentées
% durant la phase de mémorisation
m_cat_unfam = ["Musique" "Véhicule" "Poisson" "Art" "Arme" "Outil" "Bâtiment" "Vêtement" "Bonbon"];

% Matrice contenant les non-mots qui corresponderont aux images du dossier
% 'Images' en ordre alphabétique
vecteur_non_mots = ["tâfethor" "sarybêt" "lenêcheg" "gecolêt" "gugareg" "labèlel" ...
    "ramomet" "gasafod" "yarevat" "lêmobur" "ceduphèc" "cosonem" "botamom" "fanisîr" ...
    "cynofép" "poçamec" "kasifoc" "cémacèm"];

% Définir les couleurs qui seront utilisées par la suite
white = [255 255 255];
grey = [255 255 255]/2;
black = [0 0 0];

% «home_dir» correspond au dossier dans lequel se trouve l'utilisateur qui
% devrait être «projet_de_session»
home_dir=cd;

% Importer les images.jpg du dossier 'Images' 
stim_path=fullfile(home_dir,sprintf('/Images/'));
temp_dir=dir(fullfile(stim_path,'*.jpg'));

% Randomiser l'ordre de présentation ultérieure des images selon les index
% qui seront dans la matrice «ordre_img_essais»
nstim=length(temp_dir); %18
n_non_mots=length(vecteur_non_mots); %18
ntrials=nstim; %18
ordre_img_essais=randperm(ntrials,ntrials);

%% logfiles
if ~exist('logfiles','dir') %on regarde s'il existe un directory, si non on en crée un
    mkdir('logfiles')
end   

addpath('logfiles');
%conversion de la variable en string pour l'utiliser comme titre du fichier
num_par = num2str(num_par);
TxtLogFile = fopen(fullfile('logfiles', ['Participant_',num_par, '.mat']),'w');
fprintf(TxtLogFile,'%18s %18s %18s \n', 'Numéro de participant','info_par','ntrials'); %18s means 18 characters space
save(fullfile('logfiles',['Participant_',num_par, '.mat']));
%% Paramètres d'initialisation de l'écran
% Définir la variable «screens» avec l'écran du participant et
% «screenNumber». Si la personne à un moniteur secondaire, ce sera celui-ci qui sera utilisé
screens=Screen('Screens');
screenNumber=max(screens);

% Forcer le script à continuer si les tests de synchronisation échouent
Screen('Preference','SkipSyncTests',1);

[window,windowRect] = Screen('OpenWindow',screenNumber,grey);

% Taille de l'écran en pixels
[screenXpixels, screenYpixels] = Screen('WindowSize', window);

%% Si la condition est '1', voici ce que la fonction exécutera:
% -> Présenter une paire non-mot + image, une à la fois à l’écran
% -> Après 5 secondes, la paire non-mot + image change pour la prochaine
if phase == 1 
    
    % Retirer le curseur de l'écran pendant l'expérimentation
    HideCursor;
    
    % Instructions pour la phase 1
    Screen('FillRect', window,white);
    Screen('TextSize', window, 30);
    Screen('TextFont', window, 'Arial');
    
    DrawFormattedText(window,'Ceci une phase de mémorisation\nUne série d''images et de non-mots sera présentée pour 5 secondes\nVotre tâche est de mémoriser les non-mots en lien avec les images','center',screenYpixels * 2/6,black,windowRect);
    DrawFormattedText(window,'Appuyez sur n''importe quelle touche pour commencer','center',screenYpixels * 4/6,black,windowRect);
    Screen('Flip',window);
    KbStrokeWait;
    
    %À la fin de la phase 1, nous allons demander au participant s'il veut continuer directement à la phase 2
    RestrictKeysForKbCheck([KbName('o') KbName('n')]);
    
    %Mettre l'écran en gris pour la phase de mémorisation
    Screen('FillRect', window,grey);
    
    % Boucle de présentation des images pairées à un non-mot
    for trial = 1:ntrials
        
        img_number=ordre_img_essais(trial);
        stim_fname=fullfile(temp_dir(img_number).folder,temp_dir(img_number).name);
        info_par.img_number(trial)=img_number;
        %info_par.stim_fname(trial)=num2str(stim_fname);
        
        %Image et non-mot présenté
        image_presented = imread(stim_fname);
        word_presented = vecteur_non_mots(ordre_img_essais(trial));
        
        %Redimensionner l'image à un ratio qui correspond au 1/3
        %de la largeur et de la hauteur de l'écran pour chacune des images.
        %Ainsi, toutes les images présentées ont la même taille par rapport
        %à l'écran.
        newWidth = screenXpixels/3;
        newHeight = screenYpixels/3;
        image_presented_croped = imresize(image_presented, [newHeight newWidth]);
        
        image_texture = Screen('MakeTexture',window,image_presented_croped);
        
        Screen('DrawTexture',window,image_texture,[],[]);
        
        % Initialisation de paramètre de police et initialisation du
        % non-mot qui sera présenté sous l'image
        Screen('TextSize', window, 90);
        Screen('TextFont', window, 'Times');
        DrawFormattedText(window,num2str(word_presented),'center',screenYpixels * 0.75,white,windowRect);
        
        %Présenter les images et non-mots à l'écran
        Screen('Flip',window);
        
        %Attendre 5 secondes avant de passer à l'image suivante
        WaitSecs(1);
        trial = trial + 1;
    end
    
    % Demander à l'évaluateur s'il veut poursuivre directement à la phase 2
    Screen('FillRect', window,white);
    Screen('TextSize', window, 30);
    Screen('TextFont', window, 'Arial');
    DrawFormattedText(window,'Voulez-vous continuer directement à la phase 2?\nAppuyez sur «o» pour aller à la phase 2\nAppuyez sur «n» pour arrêter ici','center','center',black,windowRect);
    Screen('Flip',window);
    
    KbWait;
    
    [~,~,keyCode,~] = KbCheck;
    
    if keyCode(KbName('o'))
        phase = 2;
    elseif keyCode(KbName('n'))
        Screen('CloseAll');
    end
end
%% Si la phase entrée est 2, voici ce que la fonction exécutera:
% Un non mot sera présenté en bas au centre de l'écran et deux catégories
% sémantiques seront présentées dans les coins supérieurs gauche et droite.
% Se référer au «Lisez-moi.txt» pour plus de détails sur cette phase.
if phase == 2

    %Cette partie du code représente une partie importante de la phase 2. Nous
    %générons d'abord une matrice de 12 non-mots sélectionné aléatoirement
    %parmi les 18 non-mots qui ont été présenté durant la phase de
    %mémorisation. Par la suite, nous avons une boucle qui parcours chaque
    %cases de la matrice «m_catEtNonMot» pour récupérer la catégorie des
    %non-mots qui seront testés (i.e. ceux de la matrice «mots_phase2»).
    
    % Instructions pour la phase 2
    RestrictKeysForKbCheck([]);
    Screen('FillRect', window,white);
    Screen('TextSize', window, 30);
    Screen('TextFont', window, 'Arial');
    
    DrawFormattedText(window,'Des non-mots seront présentés avec deux catégories \nVous devez sélectionner la catégorie qui correspond au non-mot \nPour sélectionner la catégorie de gauche, appuyez sur «z» \nPour sélectionner la catégorie de droite, appuyez sur «m» \nAppuyez sur n''importe quelle touche pour commencer','centerblock','center',black,windowRect);
    Screen('Flip',window);
    KbStrokeWait;
    
    %Martice de 12 nombres aléatoires entre 1 et 18
    m_12rand = randperm(18,12);
    %Matrice qui contiendra les non-mots aux positions correspondantes de
    %la matrice m_12rand
    mots_phase2 = ["","","","","","","","","","","",""];
    
    %Boucle qui parcours les cases de la matrice m_12rand en insérant le
    %mot correspondant à cette position dans la matrice mots_phase2. De
    %cette façon, les mots qui seront testés seront aléatoirement définit
    %entre les participants
    for compteur = 1:length(m_12rand)
        
        index = m_12rand(compteur);
        mots_phase2(compteur) = vecteur_non_mots(index);
        
        compteur = compteur+1;
    end
    
    %Matrice contenant la position du mot qu'on cherche ([rangée colonne])
    position_mot_ran_col = [];
    %Selon le mot qu'on cherche, la catégorie correspondante à ce mot sera
    %enregistrée dans cette matrice
    categorie_mot_phase2 = ["","","","","","","","","","","",""];
    
    for index = 1:length(mots_phase2)
        for rangee = 2:3
            for colonne = 1:9
                if mots_phase2(index) == m_catEtNonMot(rangee,colonne)
                    position_mot_ran_col = [rangee colonne];
                    categorie_mot_phase2(1,index) = m_catEtNonMot(1,colonne);
                else
                    continue
                end
            end
        end
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %La partie suivante représente les procédures pour afficher le non-mots
    %présenté en bas au centre de l'écran et en haut, d'un côté une
    %catégorie présentée (la bonne ou non, selon la condition) et de
    %l'autre, une catégorie jamais présentée.
    
    % Restrict keys to 'z' (29) and 'm' (16)
    RestrictKeysForKbCheck([KbName('z') KbName('m')]);
    % Remove Cursor from screen during experiment
    HideCursor;
    
    %Initialiser les matrices qui contiendront les informations à extraire
    %pour le participant (TR, réponse à chaque essai et la condition selon
    %l'essai)
    tempsRep = [];
    repEssai = ["","","","","","","","","","","",""];
    conditionCat = [];
    sideBonneCat = ["","","","","","","","","","","",""];
    
    %Matrice de six 0 et six 1 pour déterminer quele condition sera
    %présentée et s'assurer que chacune est présentée six fois
    controle_conditions = [0,0,0,0,0,0,1,1,1,1,1,1];
    %permutation aléatoire pour randominer les conditions
    controle_conditions = randsample(controle_conditions,length(controle_conditions));
    controle_conditions = Shuffle(controle_conditions);
    
    for compteur = 1:length(mots_phase2)
        
        Screen('FillRect', window,white);
        Screen('Flip',window);
        WaitSecs(1);
        
        Screen('FillRect', window,grey);
        
        %Non-mot qui sera testé à l'essai «compteur»
        motTest = mots_phase2(1,compteur);
        
        %Bonne catégorie sémantique correspondant au non-mot présenté
        bonneCat = categorie_mot_phase2(1,compteur);
        
        %Catégorie qui a été présenté, mais qui ne correspond pas à la
        %catégorie sémantique qui correspond au non-mot présenté
        mauvaiseCat = m_catEtNonMot(1,randi([1 9]));
        %Si la catégorie est la même que la bonne catégorie, changer de
        %catégorie
        if mauvaiseCat == bonneCat
            mauvaiseCat = m_catEtNonMot(1,randi([1 9]));
        end
        
        %Catégorie jamais présenté qui sera présentée à cet essai
        catJamaisPres = m_cat_unfam(1,randi([1 9]));
        
        %Morceau pour formater la police et la taille
        Screen('TextSize', window, 90);
        Screen('TextFont', window, 'Times');
        
        %Définir aléatoire si la condition sera 0 (on présente la bonne
        %catégorie d'un côté et une catégorie jamais présentée de l'autre)
        %ou 1 (on présente la mauvaise catégorie d'un côté et une catégorie
        %jamais présentée de l'autre).
        condition = controle_conditions(compteur);
        conditionCat(compteur) = condition;
        
          gauche = screenXpixels * 0.18;
          droite = screenXpixels * 0.68;
          
          side = [gauche droite];  
          side=side(randperm(length(side)));
          
          if side(1) < side(2)
              sideBonneCat(compteur) = "gauche";
          elseif side(1) > side(2)
              sideBonneCat(compteur) = "droite";
          end
        
        %Condition 0 --> bonne catégorie et mauvaise catégorie
        if condition == 0
            
            DrawFormattedText(window,num2str(motTest),'center',screenYpixels * 0.75,white,windowRect);
            
            DrawFormattedText(window,num2str(bonneCat),side(1),screenYpixels * 0.25,white,windowRect);
            
            DrawFormattedText(window,num2str(mauvaiseCat),side(2),screenYpixels * 0.25,white,windowRect);
            
            %Condition 1 --> bonne catégorie et catégorie jamais présentée
        elseif condition == 1
            DrawFormattedText(window,num2str(motTest),'center',screenYpixels * 0.75,white,windowRect);
            
            DrawFormattedText(window,num2str(bonneCat),side(1),screenYpixels * 0.25,white,windowRect);
            
            DrawFormattedText(window,num2str(catJamaisPres),side(2),screenYpixels * 0.25,white,windowRect);
            
        end
        
        % set time 0 (for reaction time)
        secs0 = GetSecs;
        
        Screen('Flip',window);
        
        %Durée de la présentation des mots avant que le participant puisse
        %appuyer sur une touche
        WaitSecs(0.1);
        
        KbWait;
        
        % Enregistrer les touches du clavier
        [keyIsDown, secs, keyCode, deltaSecs] = KbCheck;% Wait for and checkwhich key was pressed
        response = KbName(keyCode);
        
        RT=(secs-secs0) - 0.1;% Get reaction time
        
        %Enregistrer les réponses à chaque essai dans la matrice «repEssai»
        repEssai(compteur) = (response);
       
        %Enregistrer les TR à chaque essai dans la matrice «tempsRep»
        tempsRep(1,compteur) = RT;
        
    end
    
    info_par.TempsRep = tempsRep;
    info_par.ReponseEssai = repEssai;
    info_par.ConditionCategories = conditionCat;
    info_par.SideBonneCategorie = sideBonneCat;
end

Screen('CloseAll');
%% Exporter les informations contenues dans la structure «info_par»
if phase == 2
    save(fullfile('logfiles',['Participant_',num_par,'.mat']),'info_par','tempsRep','repEssai','conditionCat','sideBonneCat','img_number');

end